A simple morsecode generator with 2 example implementations as seen in: 
"Arduino - schneller Einstieg" by Maik Schmidt